import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Dahlsens Competitive Capability Assessment", description: "Internal perception-based competitor benchmarking across the complete commercial chain." };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }
